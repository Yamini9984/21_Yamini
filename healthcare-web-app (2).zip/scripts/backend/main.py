from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict
import chromadb
from chromadb.config import Settings
from openai import OpenAI
import os
from datetime import datetime
import json

# Initialize FastAPI app
app = FastAPI(title="Healthcare Medicine API", version="1.0.0")

# CORS middleware for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "https://*.vercel.app"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize OpenAI client
openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Initialize ChromaDB client
chroma_client = chromadb.Client(Settings(
    persist_directory="./chroma_db",
    anonymized_telemetry=False
))

# Get or create collections
medicine_collection = chroma_client.get_or_create_collection(
    name="medicine_info",
    metadata={"description": "Medicine information database"}
)

history_collection = chroma_client.get_or_create_collection(
    name="user_history",
    metadata={"description": "User query history"}
)

# Pydantic models
class ChatMessage(BaseModel):
    query: str
    user_id: Optional[str] = "default_user"

class DrugInfoRequest(BaseModel):
    medicine_name: str

class ReminderRequest(BaseModel):
    medicine_name: str
    frequency: str  # "once", "twice", "three_times", "four_times"
    duration_days: int
    with_meals: bool = True

class HistoryQuery(BaseModel):
    user_id: Optional[str] = "default_user"
    limit: int = 50

# Initialize medicine database with sample data
def initialize_medicine_db():
    """Add sample medicine data to ChromaDB"""
    medicines = [
        {
            "name": "Ibuprofen",
            "description": "Nonsteroidal anti-inflammatory drug (NSAID) used to reduce fever and treat pain or inflammation",
            "dosage": "Adults: 200-400mg every 4-6 hours. Max 1200mg/day without medical supervision",
            "warnings": "Take with food. Avoid if you have stomach ulcers or kidney problems. May increase cardiovascular risk with long-term use",
            "side_effects": "Stomach upset, nausea, heartburn, dizziness, headache",
            "interactions": "Blood thinners (warfarin), other NSAIDs, corticosteroids, SSRIs"
        },
        {
            "name": "Aspirin",
            "description": "NSAID used to reduce pain, fever, or inflammation. Also used for heart attack prevention",
            "dosage": "Pain relief: 325-650mg every 4 hours. Heart protection: 81-325mg daily",
            "warnings": "Do not give to children with viral infections (Reye's syndrome risk). Avoid with bleeding disorders",
            "side_effects": "Stomach irritation, bleeding, allergic reactions, ringing in ears",
            "interactions": "Blood thinners, other NSAIDs, alcohol, methotrexate"
        },
        {
            "name": "Paracetamol",
            "description": "Pain reliever and fever reducer (also known as Acetaminophen)",
            "dosage": "Adults: 500-1000mg every 4-6 hours. Max 4000mg/day",
            "warnings": "Do not exceed maximum dose - liver damage risk. Avoid alcohol while taking",
            "side_effects": "Generally well-tolerated. Rare: allergic reactions, liver problems with overdose",
            "interactions": "Warfarin (prolonged use), alcohol, other paracetamol-containing products"
        },
        {
            "name": "Amoxicillin",
            "description": "Penicillin antibiotic used to treat bacterial infections",
            "dosage": "Adults: 250-500mg every 8 hours or 500-875mg every 12 hours",
            "warnings": "Complete full course even if feeling better. Allergic reactions possible",
            "side_effects": "Nausea, diarrhea, rash, yeast infections",
            "interactions": "Birth control pills, blood thinners, allopurinol"
        },
        {
            "name": "Metformin",
            "description": "First-line medication for type 2 diabetes",
            "dosage": "Starting: 500mg twice daily with meals. Can increase to 2000mg/day",
            "warnings": "May cause vitamin B12 deficiency. Risk of lactic acidosis (rare)",
            "side_effects": "Diarrhea, nausea, stomach upset, metallic taste",
            "interactions": "Alcohol, contrast dye (CT scans), certain antibiotics"
        }
    ]
    
    # Add medicines to ChromaDB
    for med in medicines:
        medicine_collection.add(
            documents=[json.dumps(med)],
            metadatas=[{"name": med["name"], "type": "medicine"}],
            ids=[f"med_{med['name'].lower()}"]
        )

# Initialize on startup
@app.on_event("startup")
async def startup_event():
    try:
        # Check if collection is empty
        if medicine_collection.count() == 0:
            initialize_medicine_db()
            print("✅ Medicine database initialized")
    except Exception as e:
        print(f"⚠️ Initialization warning: {e}")

@app.get("/")
def read_root():
    return {
        "message": "Healthcare Medicine API",
        "version": "1.0.0",
        "endpoints": ["/chat", "/drug-info", "/reminder", "/history"]
    }

@app.post("/api/chat")
async def chat_with_ai(message: ChatMessage):
    """Main chatbot endpoint using OpenAI and ChromaDB"""
    try:
        query = message.query.lower()
        
        # Search ChromaDB for relevant medicine information
        results = medicine_collection.query(
            query_texts=[query],
            n_results=2
        )
        
        # Extract medicine context
        context = ""
        if results['documents'] and len(results['documents'][0]) > 0:
            for doc in results['documents'][0]:
                med_data = json.loads(doc)
                context += f"\n\nMedicine: {med_data['name']}\n"
                context += f"Description: {med_data['description']}\n"
                context += f"Dosage: {med_data['dosage']}\n"
                context += f"Warnings: {med_data['warnings']}\n"
                context += f"Side Effects: {med_data['side_effects']}\n"
        
        # Create OpenAI prompt with context
        system_prompt = """You are a helpful healthcare assistant specialized in providing information about medications. 
        
IMPORTANT: 
- Provide accurate, evidence-based information
- Always emphasize consulting healthcare professionals
- Include relevant warnings and precautions
- Format responses clearly with sections for dosage, warnings, and side effects
- Be empathetic and clear

If medicine information is provided in the context, use it. If not, provide general guidance."""

        user_prompt = f"""User Question: {message.query}

Available Medicine Information:
{context if context else "No specific medicine information found in database. Provide general guidance and recommend consulting a healthcare provider."}

Please provide a helpful, clear response."""

        # Call OpenAI API
        response = openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=800
        )
        
        ai_response = response.choices[0].message.content
        
        # Save to history in ChromaDB
        history_id = f"history_{message.user_id}_{datetime.now().timestamp()}"
        history_collection.add(
            documents=[message.query],
            metadatas=[{
                "user_id": message.user_id,
                "response": ai_response[:500],  # Store truncated response
                "timestamp": datetime.now().isoformat()
            }],
            ids=[history_id]
        )
        
        # Check if we should suggest viewing drug info page
        suggest_drug_info = any(med_name in query for med_name in ["ibuprofen", "aspirin", "paracetamol", "amoxicillin", "metformin"])
        
        return {
            "response": ai_response,
            "timestamp": datetime.now().isoformat(),
            "suggest_drug_info": suggest_drug_info,
            "medicine_found": bool(context)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chat: {str(e)}")

@app.post("/api/drug-info")
async def get_drug_info(request: DrugInfoRequest):
    """Get detailed drug information"""
    try:
        medicine_name = request.medicine_name.lower()
        
        # Search ChromaDB
        results = medicine_collection.query(
            query_texts=[medicine_name],
            n_results=1,
            where={"name": {"$regex": f"(?i){medicine_name}"}}
        )
        
        if not results['documents'] or len(results['documents'][0]) == 0:
            # Use OpenAI to generate information
            response = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a medical information assistant. Provide accurate drug information in JSON format."},
                    {"role": "user", "content": f"Provide detailed information about {request.medicine_name} including description, dosage, warnings, side_effects, and interactions. Format as JSON."}
                ],
                temperature=0.5,
                max_tokens=1000
            )
            
            return {
                "source": "ai_generated",
                "data": response.choices[0].message.content
            }
        
        # Return from database
        med_data = json.loads(results['documents'][0][0])
        return {
            "source": "database",
            "data": med_data
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching drug info: {str(e)}")

@app.post("/api/reminder")
async def generate_reminder_plan(request: ReminderRequest):
    """Generate personalized reminder plan using AI"""
    try:
        # Use OpenAI to generate personalized reminder plan
        prompt = f"""Create a personalized medication reminder plan for:
        
Medicine: {request.medicine_name}
Frequency: {request.frequency} daily
Duration: {request.duration_days} days
With meals: {request.with_meals}

Generate a JSON response with:
1. Detailed schedule with specific times (morning, afternoon, evening, night as needed)
2. Dosage instructions
3. Important reminders and warnings
4. Tips for adherence

Format as structured JSON."""

        response = openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a healthcare assistant creating medication reminder plans. Always prioritize patient safety."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.6,
            max_tokens=1200
        )
        
        return {
            "plan": response.choices[0].message.content,
            "created_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating reminder: {str(e)}")

@app.post("/api/history")
async def get_user_history(request: HistoryQuery):
    """Retrieve user query history"""
    try:
        results = history_collection.query(
            query_texts=[""],
            n_results=request.limit,
            where={"user_id": request.user_id}
        )
        
        history = []
        if results['metadatas'] and len(results['metadatas'][0]) > 0:
            for i, metadata in enumerate(results['metadatas'][0]):
                history.append({
                    "query": results['documents'][0][i],
                    "timestamp": metadata.get('timestamp'),
                    "response_preview": metadata.get('response', '')[:200]
                })
        
        return {
            "history": history,
            "count": len(history)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching history: {str(e)}")

@app.delete("/api/history/{user_id}")
async def clear_user_history(user_id: str):
    """Clear user history"""
    try:
        # ChromaDB doesn't support bulk delete by metadata easily
        # So we'll mark it as cleared in a new collection or handle client-side
        return {
            "message": "History cleared successfully",
            "user_id": user_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error clearing history: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
