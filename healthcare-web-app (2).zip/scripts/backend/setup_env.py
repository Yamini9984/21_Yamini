"""
Setup script to create .env file for FastAPI backend
"""

env_content = """# OpenAI API Configuration
OPENAI_API_KEY=your_openai_api_key_here

# FastAPI Configuration
API_HOST=0.0.0.0
API_PORT=8000

# ChromaDB Configuration
CHROMA_PERSIST_DIR=./chroma_db

# CORS Origins (comma-separated)
CORS_ORIGINS=http://localhost:3000,https://*.vercel.app
"""

with open('.env', 'w') as f:
    f.write(env_content)

print("✅ .env file created!")
print("⚠️  Please update OPENAI_API_KEY in the .env file")
