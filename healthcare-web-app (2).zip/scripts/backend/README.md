# Healthcare Medicine API - FastAPI Backend

Complete backend system with OpenAI integration and ChromaDB vector storage.

## Features

- **AI-Powered Chat**: OpenAI GPT-4 for intelligent medicine queries
- **Vector Database**: ChromaDB for efficient medicine information storage and retrieval
- **Reminder System**: AI-generated personalized medication schedules
- **History Tracking**: Store and retrieve user query history
- **Drug Information**: Comprehensive medicine database with search

## Installation

### 1. Install Dependencies

```bash
cd scripts/backend
pip install -r requirements.txt
```

### 2. Setup Environment Variables

```bash
python setup_env.py
```

Then edit `.env` and add your OpenAI API key:

```
OPENAI_API_KEY=sk-your-actual-key-here
```

### 3. Run the Server

```bash
python main.py
```

Or with uvicorn directly:

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## API Endpoints

### 1. Health Check
```
GET http://localhost:8000/
```

### 2. Chat with AI
```
POST http://localhost:8000/api/chat
Content-Type: application/json

{
  "query": "What are the side effects of ibuprofen?",
  "user_id": "user123"
}
```

### 3. Get Drug Information
```
POST http://localhost:8000/api/drug-info
Content-Type: application/json

{
  "medicine_name": "Ibuprofen"
}
```

### 4. Generate Reminder Plan
```
POST http://localhost:8000/api/reminder
Content-Type: application/json

{
  "medicine_name": "Ibuprofen 400mg",
  "frequency": "three_times",
  "duration_days": 7,
  "with_meals": true
}
```

### 5. Get User History
```
POST http://localhost:8000/api/history
Content-Type: application/json

{
  "user_id": "user123",
  "limit": 50
}
```

### 6. Clear History
```
DELETE http://localhost:8000/api/history/user123
```

## Architecture

### ChromaDB Collections

1. **medicine_info**: Stores medicine data with vector embeddings
2. **user_history**: Stores user queries and responses

### OpenAI Integration

- Model: GPT-4 Turbo Mini
- Temperature: 0.7 for chat, 0.5 for drug info
- Context-aware responses using ChromaDB retrieval

### Pre-loaded Medicines

- Ibuprofen
- Aspirin
- Paracetamol
- Amoxicillin
- Metformin

## Testing

Use the provided API documentation at:
```
http://localhost:8000/docs
```

Or use curl:

```bash
# Test chat endpoint
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "Tell me about ibuprofen"}'
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| OPENAI_API_KEY | Your OpenAI API key | Yes |
| API_HOST | Server host | No (default: 0.0.0.0) |
| API_PORT | Server port | No (default: 8000) |
| CHROMA_PERSIST_DIR | ChromaDB storage path | No (default: ./chroma_db) |

## Error Handling

All endpoints return structured error responses:

```json
{
  "detail": "Error message here"
}
```

## Security Notes

- CORS is configured for localhost:3000 and Vercel deployments
- Never commit .env file with API keys
- Use environment variables in production
- Consider rate limiting for production use

## Next Steps

1. Add authentication/authorization
2. Implement rate limiting
3. Add more medicines to database
4. Create admin panel for medicine management
5. Add analytics and logging
