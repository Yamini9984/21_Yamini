export interface Medicine {
  name: string
  category: string
  description: string
  uses: string[]
  dosage: {
    adults: string
    children: string
    maximum: string
  }
  warnings: string[]
  sideEffects: {
    common: string[]
    serious: string[]
  }
  interactions: string[]
  form: string[]
  duration: string
}

export const medicineDatabase: Medicine[] = [
  {
    name: "Ibuprofen",
    category: "Nonsteroidal Anti-Inflammatory Drug (NSAID)",
    description:
      "Ibuprofen is used to reduce fever and treat pain or inflammation caused by many conditions such as headache, toothache, back pain, arthritis, menstrual cramps, or minor injury.",
    uses: [
      "Relief of mild to moderate pain",
      "Reduction of fever",
      "Treatment of inflammation",
      "Management of arthritis symptoms",
      "Menstrual cramp relief",
    ],
    dosage: {
      adults: "200-400mg every 4-6 hours",
      children: "Dosage based on weight and age - consult pediatrician",
      maximum: "1200mg daily without medical supervision",
    },
    warnings: [
      "May increase risk of heart attack or stroke with long-term use",
      "Do not use if allergic to NSAIDs",
      "Avoid if you have stomach ulcers or bleeding",
      "Not recommended in last trimester of pregnancy",
      "Consult doctor if you have heart, kidney, or liver disease",
    ],
    sideEffects: {
      common: ["Upset stomach", "Nausea", "Heartburn", "Dizziness", "Headache"],
      serious: [
        "Black or bloody stools",
        "Chest pain",
        "Shortness of breath",
        "Severe allergic reaction",
        "Vision changes",
      ],
    },
    interactions: [
      "Blood thinners (warfarin, aspirin)",
      "Other NSAIDs",
      "Blood pressure medications",
      "Antidepressants (SSRIs)",
      "Corticosteroids",
    ],
    form: ["Tablet", "Capsule", "Liquid"],
    duration: "4-6 hours per dose",
  },
  {
    name: "Paracetamol",
    category: "Analgesic and Antipyretic",
    description:
      "Paracetamol (Acetaminophen) is used to treat pain and reduce fever. It's one of the most commonly used pain relievers worldwide.",
    uses: ["Pain relief", "Fever reduction", "Headache treatment", "Cold and flu symptoms"],
    dosage: {
      adults: "500-1000mg every 4-6 hours",
      children: "Based on weight - 10-15mg/kg every 4-6 hours",
      maximum: "4000mg daily for adults",
    },
    warnings: [
      "Do not exceed recommended dose - can cause liver damage",
      "Avoid alcohol while taking paracetamol",
      "Consult doctor if you have liver disease",
      "Check other medications for paracetamol content to avoid overdose",
    ],
    sideEffects: {
      common: ["Generally well-tolerated", "Rare: mild rash"],
      serious: ["Liver damage with overdose", "Severe allergic reactions (rare)", "Blood disorders (very rare)"],
    },
    interactions: [
      "Warfarin (may increase bleeding risk)",
      "Alcohol (increases liver toxicity risk)",
      "Carbamazepine",
      "Phenytoin",
    ],
    form: ["Tablet", "Capsule", "Liquid", "Suppository"],
    duration: "4-6 hours per dose",
  },
  {
    name: "Aspirin",
    category: "Nonsteroidal Anti-Inflammatory Drug (NSAID)",
    description:
      "Aspirin is used to reduce pain, fever, or inflammation. It's also used in low doses to prevent heart attacks and strokes.",
    uses: [
      "Pain relief",
      "Fever reduction",
      "Anti-inflammation",
      "Heart attack prevention (low dose)",
      "Stroke prevention",
    ],
    dosage: {
      adults: "Pain relief: 300-900mg every 4-6 hours. Cardioprotection: 75-150mg daily",
      children: "Not recommended for children under 16 due to Reye's syndrome risk",
      maximum: "4000mg daily for pain relief",
    },
    warnings: [
      "Do not give to children under 16 (risk of Reye's syndrome)",
      "Increased bleeding risk",
      "Stomach ulcer risk",
      "Consult doctor if pregnant or breastfeeding",
      "Avoid if allergic to NSAIDs",
    ],
    sideEffects: {
      common: ["Stomach upset", "Indigestion", "Nausea"],
      serious: [
        "Stomach bleeding",
        "Allergic reactions",
        "Ringing in ears (tinnitus)",
        "Severe bleeding",
        "Kidney problems",
      ],
    },
    interactions: [
      "Blood thinners (warfarin)",
      "Other NSAIDs (ibuprofen)",
      "Methotrexate",
      "Corticosteroids",
      "ACE inhibitors",
    ],
    form: ["Tablet", "Chewable tablet", "Enteric-coated tablet"],
    duration: "4-6 hours per dose",
  },
  {
    name: "Amoxicillin",
    category: "Antibiotic (Penicillin)",
    description:
      "Amoxicillin is a penicillin antibiotic used to treat bacterial infections including chest infections, dental abscesses, and urinary tract infections.",
    uses: [
      "Bacterial respiratory infections",
      "Ear infections",
      "Throat infections",
      "Urinary tract infections",
      "Dental infections",
      "Skin infections",
    ],
    dosage: {
      adults: "250-500mg three times daily or 500-875mg twice daily",
      children: "Based on weight - typically 20-40mg/kg/day in divided doses",
      maximum: "Usually 500mg three times daily or as prescribed",
    },
    warnings: [
      "Do not use if allergic to penicillin antibiotics",
      "Complete full course even if feeling better",
      "May reduce effectiveness of oral contraceptives",
      "Inform doctor if you have kidney disease",
      "Can cause antibiotic-associated diarrhea",
    ],
    sideEffects: {
      common: ["Nausea", "Diarrhea", "Rash", "Vomiting"],
      serious: [
        "Severe allergic reaction (anaphylaxis)",
        "Severe skin reactions",
        "Liver problems",
        "Clostridium difficile infection",
      ],
    },
    interactions: [
      "Oral contraceptives (reduced effectiveness)",
      "Methotrexate",
      "Allopurinol (increased rash risk)",
      "Blood thinners",
    ],
    form: ["Capsule", "Tablet", "Liquid suspension", "Chewable tablet"],
    duration: "Complete 5-10 day course as prescribed",
  },
  {
    name: "Metformin",
    category: "Antidiabetic (Biguanide)",
    description:
      "Metformin is used to treat type 2 diabetes. It helps control blood sugar levels and is often the first medication prescribed for type 2 diabetes.",
    uses: [
      "Type 2 diabetes management",
      "Blood sugar control",
      "May be used for polycystic ovary syndrome (PCOS)",
      "Prediabetes prevention",
    ],
    dosage: {
      adults: "Starting dose: 500mg twice daily or 850mg once daily. Maximum: 2000-2500mg daily in divided doses",
      children: "For children 10+ years: starting 500mg twice daily, max 2000mg daily",
      maximum: "2500mg daily in divided doses",
    },
    warnings: [
      "Risk of lactic acidosis (rare but serious)",
      "Do not use if you have severe kidney disease",
      "Stop before surgery or imaging tests with contrast dye",
      "Avoid excessive alcohol consumption",
      "May cause vitamin B12 deficiency with long-term use",
    ],
    sideEffects: {
      common: ["Diarrhea", "Nausea", "Stomach upset", "Metallic taste", "Loss of appetite"],
      serious: [
        "Lactic acidosis (rare)",
        "Severe allergic reactions",
        "Low blood sugar (when combined with other diabetes medications)",
      ],
    },
    interactions: [
      "Contrast dye for imaging",
      "Other diabetes medications (insulin, sulfonylureas)",
      "Alcohol",
      "Certain blood pressure medications",
      "Corticosteroids",
    ],
    form: ["Tablet", "Extended-release tablet", "Liquid"],
    duration: "Long-term daily medication",
  },
]

export function searchMedicine(query: string): Medicine | undefined {
  const normalizedQuery = query.toLowerCase().trim()
  return medicineDatabase.find((med) => med.name.toLowerCase() === normalizedQuery)
}

export function getMedicineContext(medicine: Medicine): string {
  return `
Medicine: ${medicine.name}
Category: ${medicine.category}
Description: ${medicine.description}

Uses: ${medicine.uses.join(", ")}

Dosage:
- Adults: ${medicine.dosage.adults}
- Children: ${medicine.dosage.children}
- Maximum: ${medicine.dosage.maximum}

Warnings: ${medicine.warnings.join(". ")}

Common Side Effects: ${medicine.sideEffects.common.join(", ")}
Serious Side Effects: ${medicine.sideEffects.serious.join(", ")}

Drug Interactions: ${medicine.interactions.join(", ")}

Available Forms: ${medicine.form.join(", ")}
Duration: ${medicine.duration}
  `.trim()
}

export function getAllMedicineNames(): string[] {
  return medicineDatabase.map((med) => med.name)
}
