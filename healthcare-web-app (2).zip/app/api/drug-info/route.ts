import { searchMedicine, getMedicineContext } from "@/lib/medicine-database"

export async function POST(request: Request) {
  try {
    const { medicine_name } = await request.json()

    if (!medicine_name) {
      return Response.json({ error: "Medicine name is required" }, { status: 400 })
    }

    const medicine = searchMedicine(medicine_name)

    if (!medicine) {
      return Response.json(
        {
          error: `Medicine "${medicine_name}" not found in database. Available medicines: Ibuprofen, Paracetamol, Aspirin, Amoxicillin, Metformin`,
        },
        { status: 404 },
      )
    }

    return Response.json({
      medicine: medicine,
      context: getMedicineContext(medicine),
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] Drug info API error:", error)
    return Response.json({ error: "Failed to fetch drug information" }, { status: 500 })
  }
}
