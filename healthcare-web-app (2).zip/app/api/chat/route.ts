import { generateText } from "ai"
import { getMedicineContext, medicineDatabase } from "@/lib/medicine-database"

export async function POST(request: Request) {
  try {
    const { query } = await request.json()

    if (!query) {
      return Response.json({ error: "Query is required" }, { status: 400 })
    }

    let context = `Available medicines in database: ${medicineDatabase.map((m) => m.name).join(", ")}\n\n`

    // Try to find specific medicine mentioned in query
    for (const medicine of medicineDatabase) {
      if (query.toLowerCase().includes(medicine.name.toLowerCase())) {
        context += getMedicineContext(medicine) + "\n\n"
      }
    }

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a helpful medical information assistant. Provide accurate, clear information about medicines based on the context provided. Always remind users to consult healthcare professionals for medical advice. Be concise but thorough.

${context}

Important: If asked about a medicine not in the database, politely inform the user and suggest they consult a healthcare professional or pharmacist.`,
        },
        {
          role: "user",
          content: query,
        },
      ],
    })

    return Response.json({
      response: text,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return Response.json(
      {
        error: "Failed to generate response. Please try again.",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
