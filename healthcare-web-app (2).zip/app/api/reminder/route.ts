import { generateText } from "ai"
import { searchMedicine, getMedicineContext } from "@/lib/medicine-database"

export async function POST(request: Request) {
  try {
    const { medicine_name, frequency, duration_days, with_meals } = await request.json()

    if (!medicine_name || !frequency || !duration_days) {
      return Response.json({ error: "Missing required fields" }, { status: 400 })
    }

    const medicine = searchMedicine(medicine_name)
    const medicineContext = medicine ? getMedicineContext(medicine) : ""

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a medical reminder assistant. Generate a detailed, personalized medication reminder plan in JSON format.

${medicineContext}

Create a reminder schedule that includes:
- Specific times for each dose
- Instructions about taking with/without meals
- Important warnings
- What to do if a dose is missed

Format the response as a JSON object with this structure:
{
  "medicine_name": "string",
  "frequency": "string",
  "duration_days": number,
  "reminders": [
    {
      "time": "HH:MM AM/PM",
      "dosage": "string",
      "instructions": "string",
      "meal_timing": "before/with/after meals or empty"
    }
  ],
  "warnings": ["string"],
  "missed_dose_instructions": "string"
}`,
        },
        {
          role: "user",
          content: `Create a reminder plan for ${medicine_name}, ${frequency} times per day for ${duration_days} days. ${with_meals ? "Should be taken with meals." : "No specific meal requirement."}`,
        },
      ],
    })

    // Parse the AI response
    const jsonMatch = text.match(/\{[\s\S]*\}/)
    const reminderPlan = jsonMatch ? JSON.parse(jsonMatch[0]) : null

    if (!reminderPlan) {
      throw new Error("Failed to parse reminder plan from AI response")
    }

    return Response.json({
      reminder_plan: reminderPlan,
      raw_response: text,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] Reminder API error:", error)
    return Response.json(
      {
        error: "Failed to generate reminder plan",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
